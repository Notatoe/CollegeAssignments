To run this code you must open the "project 3" directory in a terminal and run the command "python3 MAC_Attack.py". This will print out the hex value for the 
modified message as well as the hex value for the modified MAC.

To have this work with the test site, the MAC variable at the top of the code
must be manually replaced with the given MAC of the message
// Noah Morris
// 9/12/2020
// cosc140
//


#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <sstream>

using namespace std;

const string face[] = { "Ace", "2", "3", "4", "5", "6", "7",
                        "8", "9", "10", "Jack", "Queen", "King" }; 
const string suit[] = { "Clubs", "Diamonds", "Hearts", "Spades" };

string random_card(bool verbose=false) {
	string card;

	card = face[ rand()%13 ];
	card += " of ";
	card += suit[ rand()%4 ];

	if (verbose)
	  cout << card << "\n";

	return card;
}

int main(int argc, char *argv[])
{
	bool verbose = false;
	int seedvalue = 0;

	for (int i=1; i<argc; i++) {
	  string option = argv[i];
	  if (option.compare(0,6,"-seed=") == 0) {
	    seedvalue = atoi(&argv[i][6]);
	  } else if (option.compare("-verbose") == 0) {
	    verbose = true;
	  } else 
	    cout << "option " << argv[i] << " ignored\n";
	}

	srand(seedvalue);
	
	//initializes the table for cards, suit and card location variables, a temp string for parsing, and a marker array to tell which suit should have **
	int table[4][13] = {0};
	int s, c;
	string temp;
	string marker[4] = {""};

	while (1) 
	{
		//gets a random card and puts the string for it into a stringstream
		string card = random_card(verbose);
		stringstream ss(card);
		
		//gets the first word of the card string which holds the card value
		ss >> temp;
		
		//assigns the card value to c 
		if(temp == "Ace")
			c = 0;
		else if(temp == "Jack")
			c = 10;
		else if(temp == "Queen")
			c = 11;
		else if(temp == "King")
			c = 12;
		else
			c = atoi(temp.c_str()) - 1;

		//skips the second word, of, and gets the last word which holds the suit
		ss >> temp;
		ss >> temp;

		//assigns the value of the suit to s
		if(temp == "Clubs")
			s = 0;
		else if(temp == "Diamonds")
			s = 1;
		else if(temp == "Hearts")
			s = 2;
		else if(temp == "Spades")
			s = 3;

		//adds one to the location of the given card in the table
		table[s][c]++;
		
		//checks if any of the suits have at least one of every face card drawn
		for(int i = 0; i < 4; i++)
		{
			//gives the suit with at least one of each face card the ** marker
			if(table[i][10] != 0 && table[i][11] != 0 && table[i][12] != 0)
			{
				marker[i] = "**";
			}
		}
		
		//if any suit have the marker the program will break out of the while loop
		if(marker[0] == "**" || marker[1] == "**" || marker[2] == "**" || marker[3] == "**")
		{
			break;
		}
	}
	
	//prints out each suit with showing how much of each card was drawn as well as displaying the marker for the suit that had all of its face cards drawn
	for(int i = 0; i < 4; i++)
	{
		cout << setw(8) << suit[i] << " :" << setw(4) << table[i][0] << setw(4) << table[i][1] << setw(4) << table[i][2] << setw(4) << table[i][3] << setw(4) << table[i][4] << setw(4) << table[i][5] << setw(4) << table[i][6] << setw(4) << table[i][7] << setw(4) << table[i][8] << setw(4) << table[i][9] << setw(4) << table[i][10] << setw(4) << table[i][11] << setw(4) << table[i][12] << " " << marker[i] << '\n';

	}
}

// Noah Morris
// 9/08/2020
// cosc140
// Lab 1d
// This program takes in a string and either does simply encodes it or decodes it

#include <iostream>
#include <string>
#include <ctype.h>

using namespace std;

//function for encoding the string
void encode(string& line, int num)
{
	//for loop that goes the entire string length
	for(int i = 0; i < line.length(); i++)
	{
		//for loop that goes for how much the string is encoded
		for(int j = 0; j < num; j++)
		{
			//Capital letters
			if(line.at(i) >= 65 && line.at(i) <= 90)
			{
				line.at(i)++;

				//corrects if the letter goes above Z
				if(line.at(i) > 90)
				{
					line.at(i) -= 26;
				}
			}

			//Lowercase letters
			if(line.at(i) >= 97 && line.at(i) <= 122)
			{
				line.at(i)++;

				//corrects if the letter goes above z
				if(line.at(i) > 122)
				{
					line.at(i) -= 26;
				}
			}
		}
	}

	//prints the encoded string
	cout << line;
}

void decode(string& line, int num)
{
	//for loop that goes the entire string length
	for(int i = 0; i < line.length(); i++)
	{
		//for loop that goes for how much the string is decoded
		for(int j = 0; j < num; j++)
		{
			//Capital letters
			if(line.at(i) >= 65 && line.at(i) <= 90)
			{
				line.at(i)--;

				//corrects if the letter goes below A
				if(line.at(i) < 65)
				{
					line.at(i) += 26;
				}
			}

			//Lowercase letters
			if(line.at(i) >= 97 && line.at(i) <= 122)
			{
				line.at(i)--;

				//corrects if the letter goes below a
				if(line.at(i) < 97)
				{
					line.at(i) += 26;
				}
			}
		}
	}

	//prints the decoded string
	cout << line;
}

int main(int argc, char** argv)
{
	//error check for number of command line arguments
	if(argc != 3)
	{
		cerr << "Error, not enough command line arguments.\n";
		return -1;
	}
	//checks if the -encode or -decode was given
	if(string(argv[1]) != "-encode" && string(argv[1]) != "-decode")
	{
		cerr << "Error, incorrect command given.\n";
		return -1;
	}
	//checks if the encoding/decoding number is within 0 and 9
	if(atoi(argv[2]) < 0 || atoi(argv[2]) > 9)
	{
		cerr << "Error, number does not fit the range of 0-9.\n";
		return -1;
	}
	
	//initialzes the string for the input
	string line;

	//while loop that goes unti the user presses ctrl + d
	while(1)
	{
		//puts cin into line
		getline(cin, line);

		//breaks out of the loop if the user presses ctrl + d
		if(cin.eof())
		{
			break;
		}

		//encodes if the encode command was given and decodes if the decode command was given
		if(string(argv[1]) == "-encode")
		{
			encode(line, atoi(argv[2]));
			cout << '\n';
		}
		if(string(argv[1]) == "-decode")
		{
			decode(line, atoi(argv[2]));
			cout << '\n';
		}
	}

	return 0;
}

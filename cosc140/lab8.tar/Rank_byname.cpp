// Noah Morris
// 12/01/2020
// cosc140
// Rank_byname.cpp

#include <stdlib.h>
#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <sstream>
#include <numeric>
#include <map>
#include <vector>

using namespace std;

class name_t {
	public:
		//constructors
		name_t();
		name_t(const string &, const string &);
		
		//operator<, and print function
		bool operator<(const name_t &) const;
		void print(int = 0) const;

	private:
		string name;
};

class scores_t {
	public:
		//constructor
		scores_t();
		
		//insert, insert confirmation, and print function
		void insert(int);
		void insert_done();
		void print();

	private:
		vector<int> scores;
		float mean;
};

//default constructor that sets name to be an empty string
name_t::name_t()
{
	name = "";
}

//constructor that takes in a first and last name then puts them together
name_t::name_t(const string &first, const string &last)
{
	name = last + ", " + first;
}

//operator< takes 2 name_t objects and compares their name variables using <
bool name_t::operator<(const name_t &other) const
{
	return name < other.name;
}

//prints out the name in format
void name_t::print(int w) const
{
	cout << setw(w + 3) << setfill('.') << left << name + ' ';
}

//default constructor that sets the mean to zero
scores_t::scores_t()
{
	mean = 0.0;
}

//inserts a inputted number into the scores vector
void scores_t::insert(int num)
{
	scores.push_back(num);
}

//function that calculates the mean using the numbers within the scores vector
void scores_t::insert_done()
{
	//makes sure the scores vector is not empty
	if(scores.size() != 0)
	{
		//temperay float that has all of the numbers in scores added to it through a forloop
		float temp = 0;
		for(unsigned int i = 0; i < scores.size(); i++)
		{
			temp += scores.at(i);
		}

		//sets mean to be temp divided by the amount of numbers in scores
		mean = temp / scores.size();
	}
}

//prints out all of the inserted numbers and mean in the correct format
void scores_t::print()
{
	//sets this back to normal as it will be used after print from name_t
	cout << right << setfill(' ');
	for(unsigned int i = 0; i < scores.size(); i++)
	{
		cout << ' ' << setw(2) << scores.at(i);
	}
	cout << " : " << fixed << setprecision(1) << mean << '\n';
}

int main(int argc, char *argv[])
{
	//commandline parsing
	//argv[1]: W (width of name field)
	int W = atoi(argv[1]);

	//argv[2]: filename.txt
	string filename = argv[2];

	//open filename.txt
	ifstream ifs;
	ifs.open(filename.c_str());
	
	//map that holds a name_t and scores_t in each index
	map<name_t,scores_t> NS;

	string firstname, lastname, line;
	int num;
	while(getline(ifs, line))
	{
		//add first and lastname to name_t object
		istringstream iss(line);
		iss >> firstname >> lastname;
		name_t name(firstname, lastname);

		//inserts every number from the line to the scores_t
		scores_t score;
		while(iss >> num) 
		{
			//insert score into scores_t object
			score.insert(num);

			//have insert_done calculate mean score
			score.insert_done();
		}

		//create and insert (name_t,scores_t) pair into NS map
		NS.insert(make_pair(name, score));
	}

	//close filename.txt
	ifs.close();

	//goes through every index of NS and prints everything in name order
	map<name_t, scores_t>::iterator temp= NS.begin();
	while(temp != NS.end())
	{
		//print name
		name_t name2 = temp->first;
		name2.print(W);

		//print scores
		scores_t score2 = temp->second;
		score2.print();

		temp++;
	}
}


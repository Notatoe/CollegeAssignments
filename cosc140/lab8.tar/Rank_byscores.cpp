// Noah Morris
// 12/01/2020
// cosc140
// Rank_byscores.cpp

#include <stdlib.h>
#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <sstream>
#include <numeric>
#include <vector>
#include <algorithm>

using namespace std;

class name_t {
	public:
		//constructors
		name_t();
		name_t(const string &, const string &);

		//operator and print function
		bool operator<(const name_t &) const;
		void print(int = 0) const;

	private:
		string name;
};

class scores_t {
	public:
		//constructor
		scores_t();

		//insert, insert confirmation, print, and mean accessing functions
		void insert(int);
		void insert_done();
		void print();
		float get_mean() const;
	private:
		vector<int> scores;
		float mean;
};

class namescores_t {
	public:
		//constructors;
		namescores_t();
		namescores_t(const name_t &, const scores_t &);

		//operator<, print name, and print score functions
		bool operator<(const namescores_t &) const;
		void print_name(int = 0);
		void print_scores();

	private:
		name_t n;
		scores_t s;
};

//default constructor that sets name to be an empty string
name_t::name_t()
{
	name = "";
}

//constructor that takes in a first and last name then puts them together
name_t::name_t(const string &first, const string &last)
{
	name = last + ", " + first;
}

//operator< takes 2 name_t objects and compares their name variables using <
bool name_t::operator<(const name_t &other) const
{
	return name < other.name;
}

//prints out the name in the correct format
void name_t::print(int w) const
{
	cout << setw(w + 3) << setfill('.') << left << name + ' ';
}

//default constructor that sets mean to zero
scores_t::scores_t()
{
	mean = 0.0;
}

//inserts an inputted number into the scores vector
void scores_t::insert(int num)
{
	scores.push_back(num);
}

//function that calculates the mean using the numbers within the scores vector
void scores_t::insert_done()
{
	//makes sure the scores vector is not empty
	if(scores.size() != 0)
	{
		//temporary float that has all of the numbers in scores added to it through a forloop
		float temp = 0;
		for(unsigned int i = 0; i < scores.size(); i++)
		{
			temp += scores.at(i);
		}

		//sets mean to be temp divided by the amount of numbers in scores
		mean = temp / scores.size();
	}
}

//prints out  all of the inserted numbers and mean in the correct format
void scores_t::print()
{
	//sets this back to normal as it will be used after print from name_t
	cout << right << setfill(' ');
	for(unsigned int i = 0; i < scores.size(); i++)
	{
		cout << ' ' << setw(2) << scores.at(i);
	}
	cout << " : " << fixed << setprecision(1) << mean << '\n';
}

//public function for accessing the mean
float scores_t::get_mean() const
{
	return mean;
}

//constructor that creates a namescores_t with an empty n and s
namescores_t::namescores_t()
{
}

//constructor that sets the n and s variables
namescores_t::namescores_t(const name_t &NT, const scores_t &ST)
{
	n = NT;
	s = ST;
}

//operator that compares two namescores_t objects by their s (or n if the mean in s are equal)
bool namescores_t::operator<(const namescores_t &rhs) const
{
	//if the two means are equal, compare the name_t objects for reverse alphabetical order
	if(s.get_mean() == rhs.s.get_mean())
	{
		return rhs.n < n;
	}

	//compare the two means
	return s.get_mean() < rhs.s.get_mean();
}

//prints n using the name_t print function
void namescores_t::print_name(int w)
{
	n.print(w);
}

//prints s using the scores_t print function
void namescores_t::print_scores()
{
	s.print();
}

int main(int argc, char *argv[])
{
	//commandline parsing
	//argv[1]: W (width of name field)
	int W = atoi(argv[1]);

	//argv[2]: K (number of elements to print)
	int K = atoi(argv[2]);

	//argv[3]: filename.txt
	string filename = argv[3];

	//open filename.txt
	ifstream ifs;
	ifs.open(filename.c_str());

	//vector of namescores_t objects
	vector<namescores_t> NS;

	string firstname, lastname, line;
	int num;
	while(getline(ifs, line))
	{
		//add first and lastname to name_t object
		istringstream iss(line);
		iss >> firstname >> lastname;
		name_t name(firstname, lastname);

		//inserts every number from the line to the scores_t object
		scores_t score;
		while(iss >> num) 
		{
			//insert score into scores_t object
			score.insert(num);

			//have insert_done calculate mean score
			score.insert_done();
		}

		//create and insert namescores_t object into NS list
		namescores_t namescore(name, score);
		NS.push_back(namescore);
	}

	//close filename.txt
	ifs.close();

	//turn NS list into binary max-heap
	make_heap(NS.begin(), NS.end());

	for(int i = 0; i < K; i++)
	{
		if(NS.empty())
		{
			break;
		}

		//extract top of heap element	
		NS.at(0).print_name(W);
		NS.at(0).print_scores();

		//removes the printed namescores_t
		pop_heap(NS.begin(), NS.end());
		NS.pop_back();
	}
}

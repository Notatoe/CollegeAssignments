// Noah Morris
// 11/17/2020
// cosc140
// Lab 7

#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <iterator>
#include <algorithm>

using namespace std;

class prime_partition {
  public:
    // constructor
	prime_partition();

    // operator(int)
	void operator()(int);

  private:
	//private functions
    void create_pset();
	bool is_prime(int);
    void compute_partitions(vector<int> &, const int &, int = 0);
    void print_partitions();

	//private variables
    set<int> pset;
	int pset_min;
	int pset_max;
	int max_terms;

	//partition vector of vectors
	vector<vector<int> > partitions;
};

bool prime_partition::is_prime(int num)
{
	//sets prime to true and it will remain that way unless the number is not prime
	bool prime = true;

	//checks from 2 to half of the inputted number to make sure it is prime
	for(int i = 2; i <= num/2; i++)
	{
		//if the number is devisible by a value of i, then it is not prime
		if(num % i == 0)
		{
			prime = false;
			break;
		}
	}

	return prime;
}

void prime_partition::create_pset()
{
	//makes sure pset is empty
	pset.clear();

	//inserts every prime number from 2 to 2000
	for(int i = 2; i <= 2000; i++)
	{
		if(is_prime(i))
		{
			pset.insert(i);
		}
	}

	//sets pset_min to the first number in pset and sets pset_max to the last number in pset
	pset_min = *pset.begin();
	pset_max = *pset.end();
}

prime_partition::prime_partition()
{
	//sets up pset
	create_pset();
}

void prime_partition::operator()(int num)
{
	//makes sure the number is within the given range
	if(num < 2 || num >= 2000)
	{
		return;
	}

	//sets max_terms to 2 if even and 3 is odd
	if(num % 2 == 0)
	{
		max_terms = 2;
	}
	else
	{
		max_terms = 3;
	}

	//resets partitions to be empty
	partitions.clear();

	//sets up a temporary vector that holds primes that makes up the number
	vector<int> primes;

	//first use of compute_partitions that uses recursion
	compute_partitions(primes, num);

	//prints out the prime numbers
	print_partitions();
}

void prime_partition::print_partitions()
{
	//prints out the numbers in partitions in the correct format
	for(unsigned int i = 0; i < partitions.size(); i++)
	{
		for(unsigned int j = 0; j < partitions.at(i).size(); j++)
		{
			cout << partitions.at(i).at(j) << ' ';
		}
		cout << '\n';
	}
}

void prime_partition::compute_partitions(vector<int> &numbers, const int &target, int sum)
{
	//makes sure the sum is not larger than the target and that the vector size does not surpass max_terms
	if(sum > target || numbers.size() > max_terms)
	{
		return;
	}

	//checks if the sum is equal to the target
	if(sum == target)
	{
		//if the size of the numbers vector size is smaller than max_terms, set max_terms to the numbers vector size and clear partitions
		if(numbers.size() < max_terms)
		{
			max_terms = numbers.size();
			partitions.clear();
		}

		//pushes numbers into partitions
		partitions.push_back(numbers);
		return;
	}

	//sets start to the first element of pset
	set<int>::iterator start = pset.begin();

	//initializes end
	set<int>::iterator end;
	if(numbers.empty())
	{
		//sets end to the upperbound of target if numbers is empty
		end = upper_bound(pset.begin(), pset.end(), target);
	}
	else
	{
		//sets end to the last element of numbers otherwise
		end = upper_bound(pset.begin(), pset.end(), numbers.back());
	}

	//ii iterator that traverses the numbers vector
	set<int>::iterator ii;
	for(ii = start; ii != end; ++ii)
	{
		//temporarily puts ii into numbers and recursivly adds ii to the sum
		numbers.push_back(*ii);
		compute_partitions(numbers, target, sum + *ii);
		numbers.pop_back();
	}
}

int main(int argc, char *argv[])
{
  prime_partition goldbach;

  int number;
  while (1) {
	cout << "number = ";
    cin >> number;
	if (cin.eof())
	  break;
	
	goldbach(number);
  }

  cout << "\n";
}

// Noah Morris
// 11/3/2020
// Lab 6a

#ifndef BST_H
#define BST_H

#include <string>
#include <iomanip>
#include <iostream>
#include <queue>
#include <vector>
using namespace std;

template <class TKey>
class bst {
	struct node {
		node(int);

		void print();

		TKey key;
		int ID;

		//parent info
		node *parent;
		node *left;
		node *right;
	};

	//commented out since it is not needed yet
	/*public:
	  class iterator {
	  public:
	  default constructor (no argument)
	  overloaded operators (++, *, ==, !=)
	  private:
	  friend class bst<TKey>;
	  constructor (with argument)

	  node *p;
	  };

	//iterator begin() { ... }
	//iterator end() { ... }*/

	public:
	bst()
	{
		ID2 = 1;
		Troot=NULL; 
	}
	~bst() { clear(Troot); }

	bool empty() { return Troot==NULL; }

	void insert(TKey &);
	
	//not needed yet
	//iterator lower_bound(const TKey &);
	//iterator upper_bound(const TKey &);

	void print_bylevel();

	private:
	void clear(node *);
	node *insert(node *, TKey &);

	int ID2;
	node *Troot;
};

template<class TKey>
bst<TKey>::node::node(int id)
{
	parent = NULL;

	ID = 0;
	if(id != 0)
	{
		ID = id;
	}
}

	template <class TKey>
void bst<TKey>::node::print()
{
	//outputs the ID and the Tkey key
	cout << setw(3) << ID << ' ' << setw(3) << key << " : ";

	//output node and parent ID information
	if(parent != NULL)
	{
		cout << "P=" << setw(3) << parent->ID;
	}
	else
	{
		cout << "ROOT ";
	}

	//change below to output subtree ID information

	if(left)
		cout << " L=" << setw(3) << left->ID;
	else
		cout << "      ";
	if(right)
		cout << " R=" << setw(3) << right->ID;
	else
		cout << "      ";

	cout << "\n";
}

//specialized string version of the above goes here
template <>
void bst<string>::node::print()
{
	//outputs the node's ID and string key
	cout << setw(3) << ID << ' ' << setw(20) << key << " : ";

	//output node and parent ID information
	if(parent != NULL)
	{
		cout << "P=" << setw(3) << parent->ID;
	}
	else
	{
		cout << "ROOT ";
	}

	//change below to output subtree ID information

	if(left)
		cout << " L=" << setw(3) << left->ID;
	else
		cout << "      ";
	if(right)
		cout << " R=" << setw(3) << right->ID;
	else       cout << "      ";

	cout << "\n";
}

//bst<TKey>::iterator functions not defined above go here

	template <class TKey>
void bst<TKey>::clear(node *T)
{
	if (T) {
		clear(T->left);
		clear(T->right);
		delete T;
		T = NULL;
	}
}

	template <class TKey>
void bst<TKey>::insert(TKey &key)
{
	Troot = insert(Troot, key);
}

	template <class TKey>
class bst<TKey>::node *bst<TKey>::insert(node *T, TKey &key)
{
	//set parent link below

		if (T == NULL)
		{
			//update and set node ID
			T = new node(ID2);

			//sets the key and increases ID2 value for the the node's unique ID
			T->key = key;
			ID2 += 1;
		}
		else if (T->key == key) 
		{
			;
		}
		else if (key < T->key) 
		{
			//recursive function that goes to the left node and sets the parent to T
			T->left = insert(T->left, key);
			T->left->parent = T;
		}
		else 
		{
			//recursive function that goes to the right node and sets the parent to T
			T->right = insert(T->right, key);
			T->right->parent = T;
		}

	return T;
}

//not used yet
//bst<TKey>::lower_bound function goes here

//bst<TKey>::upper_bound function goes here

	template <class TKey>
void bst<TKey>::print_bylevel()
{
	if (Troot == NULL)
		return;

	queue<node *> Q;
	node *T;

	Q.push(Troot);
	while (!Q.empty()) {
		T = Q.front();
		Q.pop();

		T->print();
		if (T->left)  Q.push(T->left);
		if (T->right) Q.push(T->right);
	}
}
#endif

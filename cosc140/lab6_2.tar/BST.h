// Noah Morris
// 11/10/2020
// Lab 6b

#ifndef BST_H
#define BST_H

#include <string>
#include <iomanip>
#include <iostream>
#include <queue>
#include <vector>
using namespace std;

template <class TKey>
class bst {
	struct node {
		node(int);

		void print();

		TKey key;
		int ID;

		//other node info
		node *parent;
		node *left;
		node *right;
	};


	public:

	class iterator {
		public:
			//default constructor (no argument)
			iterator();

			//overloaded operators (++, *, ==, !=)
			iterator & operator++();
			TKey & operator*();
			bool operator==(const iterator &) const;
			bool operator!=(const iterator &) const;

		private:

			friend class bst<TKey>;

			//constructor (with argument)
			iterator(node *);

			node *p;
	};
	
	//begin and end functions
	iterator begin();
	iterator end();

	public:
	bst()
	{
		ID2 = 1;
		Troot=NULL; 
	}
	~bst() { clear(Troot); }

	bool empty() { return Troot==NULL; }

	void insert(TKey &);

	//lower and upper bound functions
	iterator lower_bound(const TKey &);
	iterator upper_bound(const TKey &);

	void print_bylevel();

	private:
	void clear(node *);
	node *insert(node *, TKey &);

	int ID2;
	node *Troot;
};

	template<class TKey>
bst<TKey>::node::node(int id)
{
	parent = NULL;
	left = NULL;
	right = NULL;

	ID = 0;
	if(id != 0)
	{
		ID = id;
	}
}

	template <class TKey>
void bst<TKey>::node::print()
{
	//outputs the ID and the Tkey key
	cout << setw(3) << ID << ' ' << setw(3) << key << " : ";

	//output node and parent ID information
	if(parent != NULL)
	{
		cout << "P=" << setw(3) << parent->ID;
	}
	else
	{
		cout << "ROOT ";
	}

	//change below to output subtree ID information

	if(left)
		cout << " L=" << setw(3) << left->ID;
	else
		cout << "      ";
	if(right)
		cout << " R=" << setw(3) << right->ID;
	else
		cout << "      ";

	cout << "\n";
}

//specialized string version of the above goes here
	template <>
void bst<string>::node::print()
{
	//outputs the node's ID and string key
	cout << setw(3) << ID << ' ' << setw(20) << key << " : ";

	//output node and parent ID information
	if(parent != NULL)
	{
		cout << "P=" << setw(3) << parent->ID;
	}
	else
	{
		cout << "ROOT ";
	}

	//change below to output subtree ID information

	if(left)
		cout << " L=" << setw(3) << left->ID;
	else
		cout << "      ";
	if(right)
		cout << " R=" << setw(3) << right->ID;
	else       cout << "      ";

	cout << "\n";
}

//default constructor
	template<class Tkey>
bst<Tkey>::iterator::iterator()
{
	p = NULL;
}


//constructor with argument
	template<class Tkey>
bst<Tkey>::iterator::iterator(bst<Tkey>::node *ptr)
{
	p = ptr;
}

//returns the next node by id
	template <class Tkey>
typename bst<Tkey>::iterator & bst<Tkey>::iterator::operator++()
{
	//checks for the possibilty that there is another possible node to increment to, if not set p to NULL and return
	if(p->parent == NULL && p->right == NULL) 
	{
		p = NULL;
		return *this;
	}

	//checks if there a node to the right
	if(p->right != NULL) 
	{
		//sets p to the right node and traverses to the furthest left node
		p = p->right;
		while(p->left != NULL) 
		{
			p = p->left;
		}
	}
	else
	{
		//creates a node called temp that holds the previous value of p
		node *temp = p;
		if(p->parent != NULL) 
		{
			//sets p equal to the parent
			p = p->parent;

			//keeps incrementing p until either it hits the root node or the previos p node, temp, is not to at p->right
			while(temp == p->right) 
			{
				temp = p;
				//sets p to NULL if the root node was reached from the right and returns
				if(p->parent == NULL) 
				{
					p = NULL;
					return *this;
				}
				p = p->parent;
			}
		}
	}
	return *this;
}

//returns the node's key
	template<class Tkey>
Tkey & bst<Tkey>::iterator::operator*()
{
	return p->key;
}

//returns if the node is equal to the rhs node or not
template<class Tkey>
bool bst<Tkey>::iterator::operator==(const bst<Tkey>::iterator &rhs) const
{
	return p == rhs.p;
}

//returns if the node is not equal to the rhs node or not
template<class Tkey>
bool bst<Tkey>::iterator::operator!=(const bst<Tkey>::iterator &rhs) const
{
	return p != rhs.p;
}

//returns the node with the smallest value
	template<class Tkey>
typename bst<Tkey>::iterator bst<Tkey>::begin()
{
	//if Troot is NULL return and empty iterator
	if(Troot == NULL)
	{
		return iterator();
	}

	//set temporary node to Troot and go down the nodes to the left until the furthest lef node was reached
	node *temp = Troot;
	while(temp->left != NULL)
	{
		temp = temp->left;
	}

	//return iterator that points to the furthest left node
	return iterator(temp);
}

//returns an iterator pointing to NULL
	template<class Tkey>
typename bst<Tkey>::iterator bst<Tkey>::end()
{
	return iterator();
}

	template <class TKey>
void bst<TKey>::clear(node *T)
{
	if (T) {
		clear(T->left);
		clear(T->right);
		delete T;
		T = NULL;
	}
}

	template <class TKey>
void bst<TKey>::insert(TKey &key)
{
	Troot = insert(Troot, key);
}

	template <class TKey>
class bst<TKey>::node *bst<TKey>::insert(node *T, TKey &key)
{
	//set parent link below

	if (T == NULL)
	{
		//update and set node ID
		T = new node(ID2);

		//sets the key and increases ID2 value for the the node's unique ID
		T->key = key;
		ID2 += 1;
	}
	else if (T->key == key) 
	{
		;
	}
	else if (key < T->key) 
	{
		//recursive function that goes to the left node and sets the parent to T
		T->left = insert(T->left, key);
		T->left->parent = T;
	}
	else 
	{
		//recursive function that goes to the right node and sets the parent to T
		T->right = insert(T->right, key);
		T->right->parent = T;
	}

	return T;
}

//finds the lower bound of the node the iterator point to
	template<class TKey>
typename bst<TKey>::iterator bst<TKey>::lower_bound(const TKey &key)
{
	//initializes t to Troot and n to NULL
	node *t = Troot;
	node *n = NULL;

	//while t is not equal to NULL, progress down the tree
	while(t != NULL)
	{
		//if the given key is less than or equal to the iterator's node, set n to t and progress t to the left
		if(key <= t->key)
		{
			n = t;
			t = t->left;
		}
		//else progress t to the right
		else
		{
			t = t->right;
		}
	}
	//return an iterator pointing to n
	return iterator(n);
}

//finds the upper bound of the node the iterator points to
	template<class TKey>
typename bst<TKey>::iterator bst<TKey>::upper_bound(const TKey &key)
{
	//initializes t to Troot and n to NULL
	node *t = Troot;
	node *n = NULL;

	//while t is not equal to NULL, progress down the tree
	while(t != NULL)
	{
		//if the given key is less than the iterator's node, set n to t and progress t to the left
		if(key < t->key)
		{
			n = t;
			t = t->left;
		}
		//else progress t to the right
		else
		{
			t = t->right;
		}
	}
	//return iterator pointing to n
	return iterator(n);
}

	template <class TKey>
void bst<TKey>::print_bylevel()
{
	if (Troot == NULL)
		return;

	queue<node *> Q;
	node *T;

	Q.push(Troot);
	while (!Q.empty()) {
		T = Q.front();
		Q.pop();

		T->print();
		if (T->left)  Q.push(T->left);
		if (T->right) Q.push(T->right);
	}
}
#endif

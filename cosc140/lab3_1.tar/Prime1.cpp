// Noah Morris
// 9/26/2020
// cosc140
// Prime1

#include <iostream>
#include <cmath>

using namespace std;

bool isprime(int number) 
{
	//checks for the first 8 prime numbers so that the modular division works
	if(number == 2 || number == 3 || number == 5 || number == 7 || number == 11 || number == 13 || number == 17 || number == 19)
	{
		return true;
	}
	//makes sure that the prime numbers start at 2
	else if(number < 2)
	{
		return false;
	}
	//modular division that checks if its a prime by diving by the first 8 prime numbers
	else if(number % 2 != 0 && number % 3 != 0 && number % 5 != 0 && number % 7 != 0 && number % 11 != 0 && number % 13 != 0 && number % 17 != 0 && number % 19 != 0)
	{
		return true;
	}
	return false;
};

int main()
{
	int number;
	
	while(1)
	{
		//cin takes in the inputed number and if ctrl + d is pressed the program ends
		cin >> number;

		if(cin.eof())
		{
			break;
		}

		if (isprime(number))
		{
			//the format to display prime numbers
			cout << number << " is a prime number\n";
		}
	}

	return 0;
}

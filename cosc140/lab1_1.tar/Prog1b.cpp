// Noah Morris
// 9/01/2020
// cosc 140
// Lab 1b
// This program takes in integers until forcibly stopped. Then it will output how many numbers were put in, the sum, as well as the smallest and largest number


#include <iostream>
#include <string>
#include <climits>

using namespace std;

int main()
{
	//initializes the input number, number count, the minimum number, the maximum number, and the sum with the latter 3 given initial values to be changed.
	int Input, Count;
	int Min = INT_MAX;
	int Max = INT_MIN;
	int Sum = 0;

	//while loop that goes infinitely unless the user presses ctrl + d 
	while(1)
	{
		//asks user for their input
		cin >> Input;

		//if statement that checks if user presses ctrl + d
		if(cin.eof())
		{
			//sets the minimum and maximum to 0 if a number hasn't been entered yet
			if(Count == 0)
			{
				Min = 0;
				Max = 0;
			}
			break;
		}

		//checks to make sure the user only types an integer
		if(!Input)
		{
			break;
		}

		//adds values to their respective stat
		Count++;
		Sum += Input;
		if(Input > Max)
		{
			Max = Input;
		}
		if(Input < Min)
		{
			Min = Input;
		}
	}
	
	//outputs the stats
	cout << "N   = " << Count << '\n';
	cout << "sum = " << Sum << '\n';
	cout << "min = " << Min << '\n';
	cout << "max = " << Max << '\n';

	

	return 0;
}

// Noah Morris
// 10/4/2020
// cosc140
// Prime3

#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

class isprime {
	public:
		//constructor for the isprime object with 2 in the primes vector
		isprime() {primes = {2};};
		bool operator()(int);

	private:
		//vector that holds the value of acquired primes
		vector<int> primes;
};

bool isprime::operator()(int number)
{
	//Initializes three temperary values. temp holds the number that will be checked if its prime, temp2 is used to determine how many prime numbers needs to be added to the vector, and temp3 is used to test if a number is prime
	int temp = primes.back() + 1;
	int temp2 = 0;
	int temp3 = 0;

	//binary search that checks if the prime was found withing the primes vector
	if(binary_search(primes.begin(), primes.end(), number))
	{
		//if it is not the last number in the vector then return true, otherwise add one to temp2 and keep going
		if(number != primes.back())
		{
			return true;
		}
		else
		{
			temp2++;
		}
	}
	//checks if the number is less than the largest prime in the vector and returns false if it is
	else if(primes.back() > number)
	{
		return false;
	}

	//while loop that goes until the vector has as many prime numbers as needed
	while(temp2 < 2)
	{
		//checks if its one of the first 5 primes
		if(temp == 3 || temp == 5 || temp == 7 || temp == 11)
		{
			//adds the number to the back of the vector
			primes.push_back(temp);
			
			//if the temp value is as big or is bigger than the number, then add one to temp2
			if(temp >= number)
			{
				temp2++;
			}
		}
		//checks if it is devisable by the first 5 as a preliminary check for primes
		else if(temp % 2 != 0 && temp % 3 != 0 && temp % 5 != 0 && temp % 7 != 0 && temp % 11 != 0)
		{
			//sets temp3 to zero so that it is reset every time
			temp3 = 0;
			
			//for loop that compares the temp value to every prime in the vector
			for(int i = 0; i < primes.size(); i++)
			{
				//checks if it isn't divisible or equal to any of the vectors element
				if(temp % primes.at(i) != 0 || temp == primes.at(i))
				{
					temp3++;
				}
			}
			
			//if it didn't pass every check in the for loop, then it adds one to the temp values and goes to the beginning of the while loop
			if(temp3 < primes.size())
			{
				temp++;
				continue;
			}
			
			//adds the value that has been confirmed to be prime to the vector
			primes.push_back(temp);
			
			//if the temp value is as big or is bigger than the number, then add one to temp2
			if(temp >= number)
			{
				temp2++;
			}
		}
		//if the temp value is equal to the number, then add one to temp2
		else if(temp == number)
		{
			temp2++;
		}

		//adds one to the temp value
		temp++;
	}
	
	//binary search that finds if the prime is now in the vector
	if(binary_search(primes.begin(), primes.end(), number))
	{
		return true;
	}
	return false;
}

int random_number()
{
	//returns a random number between 1 and 140
	return (rand() % 140) + 1;
}

int main(int argc, char *argv[])
{
	//declares N and sets it to 140 or the number if a number was put into the command line
	int N;
	if(argc < 2)
	{
		N = 140;
	}
	else
	{
		N = atoi(argv[1]);
	}
	
	//sets the rand() seed
	srand(N);

	//declares the vector for the int numbers and the bool values if the numbers are prime
	vector<int> numbers (N);
	vector<bool> prime (N);

	//fills out both vectors with numbers and bools
	generate(numbers.begin(), numbers.end(), random_number);
	transform(numbers.begin(), numbers.end(), prime.begin(), isprime());

	//counts the amount of primes
	int c = count(prime.begin(), prime.end(), true);

	//outputs the number of primes numbers generated
	cout << "Sequence contains " << c << " prime numbers.\n";

	return 0;
}

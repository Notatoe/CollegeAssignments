// Noah Morris
// 9/19/2020
// cosc140
// Lab 2b
// This program takes cards from a deck until a suit has had all of its face cards drawn


#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>

using namespace std;

const string face[] = { "Ace", "2", "3", "4", "5", "6", "7",
	"8", "9", "10", "Jack", "Queen", "King" }; 
const string suit[] = { "Clubs", "Diamonds", "Hearts", "Spades" };

string random_card(bool verbose=false) {
	string card;

	card = face[ rand()%13 ];
	card += " of ";
	card += suit[ rand()%4 ];

	if (verbose)
		cout << card << "\n";

	return card;
}

//single linked list class
class list
{  
	//structure for the node, includes a pointer to the next node, an int for data, and a constructor
	struct node 
	{
		node(int = -1);
		int data;
		node *next;
	};
	public:

	//constructor and deconstructor for the lists
	list();
	~list();

	// boolean function for wether a card was inserted into the suit or not
	bool insert(int card);
	
	//the overloaded operator<<
	friend ostream &operator<<(ostream &, const list &);

	private:
	//head node and number of nodes
	int N;
	node *head;
};

//implementaion taken from the handout

//constructor for nodes
list::node::node(int Newdata) 
{
	data = Newdata;
	next = NULL;
}

//list constructor
list::list()
{
	head = new node;
	N = 0;
}

//list deconstructor
list::~list()
{
	while(!(N == 0))
	{
		node *p;
		node *pp = head;
		p = pp->next;
		pp->next = p->next;
		delete p;
		N--;
	}
	delete head;
}

//insert function that returns a boolean for if or if not a card was inserted into the list
bool list::insert(int card)
{
	//two nodes with one being reserved for going back if needed
	node *p = head;
	node *p2 = head;
	
	//while loop that checks if any nodes have equal data to the one trying to be inserted
	while(p != NULL)
	{
		if(card == p->data)
		{
			//subtracts one from the number of nodes
			N--;
			
			//deletes the both of the same card and returns false
			p2->next = p->next;
			delete p;
			return 0;
		}
		//p2 saves the previous node while p moves forward
		p2 = p;
		p = p->next;
	}
	//Creates a new node and sets p and p2 back to head
	node *newNode = new node(card);
	p = head;
	p2 = head;
	
	//checks if there is only one value in the list
	if (head->next == NULL)
	{
		//adds one to the node count
		N++;
		
		//sets the node after head to the new one and returns true
		head->next = newNode;
		return 1;
	}

	//while loop that goes until it reaches the end of the list
	while(p != NULL)
	{
		//checks if the new data is less than the current node's
		if (newNode->data < p->data)
		{
			//adds one to the node count
			N++;

			//sets the node before the current node and returns true
			p2->next = newNode;
			newNode->next = p;
			return 1;
		}
		//checks if it has reached the end of the list
		else if(p->next == NULL)
		{
			//adds one to the node count
			N++;
			
			//sets the node to after the last node and returns true
			p->next = newNode;
			return 1;
		}
		
		//p2 saves the previous node while p moves forward
		p2 = p;
		p = p->next;
	}

	//returns true incase it somehow hasn't been inserted yet
	return 1;
}

//the operator<<
ostream &operator<<(ostream &out, const list &list1)
{
	//creates p as the node after head
	list::node *p = list1.head->next;

	//saves each node to out
	while (p != NULL)
	{
		out << " " << face[p->data];
		p=p->next;
	}
	
	//outputs the list
	return out;
}

int main(int argc, char *argv[])
{
	bool verbose = false;
	int seedvalue = 0;

	for (int i=1; i<argc; i++) {
		string option = argv[i];
		if (option.compare(0,6,"-seed=") == 0) {
			seedvalue = atoi(&argv[i][6]);
		} else if (option.compare("-verbose") == 0) {
			verbose = true;
		} else 
			cout << "option " << argv[i] << " ignored\n";
	}

	srand(seedvalue);

	//initializes the table for cards, suit and card location variables, a temp string for parsing, and a marker array to tell which suit should have **
	list lists[4];
	unsigned int table[4][13] = {0};
	int s, c;
	string temp;
	string marker[4] = {""};

	while (1) 
	{
		//gets a random card and puts the string for it into a stringstream
		string card = random_card(verbose);
		stringstream ss(card);

		//gets the first word of the card string which holds the card value
		ss >> temp;

		//assigns the card value to c 
		if(temp == "Ace")
			c = 0;
		else if(temp == "Jack")
			c = 10;
		else if(temp == "Queen")
			c = 11;
		else if(temp == "King")
			c = 12;
		else
			c = atoi(temp.c_str()) - 1;

		//skips the second word, of, and gets the last word which holds the suit
		ss >> temp;
		ss >> temp;

		//assigns the value of the suit to s
		if(temp == "Clubs")
			s = 0;
		else if(temp == "Diamonds")
			s = 1;
		else if(temp == "Hearts")
			s = 2;
		else if(temp == "Spades")
			s = 3;

		//adds one to the location of the given card in the table or decreases if a card wasn't inserted
		if(lists[s].insert(c))
		{
			table[s][c]++;
		}
		else
		{
			table[s][c]--;
		}

		//checks if any of the suits have at least one of every face card drawn
		for(int i = 0; i < 4; i++)
		{
			//gives the suit with at least one of each face card the ** marker
			if(table[i][10] != 0 && table[i][11] != 0 && table[i][12] != 0)
			{
				marker[i] = "**";
			}
		}

		//if any suit have the marker the program will break out of the while loop
		if(marker[0] == "**" || marker[1] == "**" || marker[2] == "**" || marker[3] == "**")
		{
			break;
		}
	}


	//prints out each suit with showing how much of each card was drawn as well as displaying the marker for the suit that had all of its face cards drawn
	for(int i = 0; i < 4; i++)
	{
		cout << setw(8) << suit[i] << " :" << lists[i] << marker[i] << '\n';
	}
}

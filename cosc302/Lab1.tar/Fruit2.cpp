// Noah Morris
// CS302
// 2/2/2020
// fruit2

// list all headers needed 
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <algorithm>
using namespace std;

struct fruit {
	//overload operators <, <=, ==, and +=
	bool operator<(const fruit &F2) const
	{
		if(name < F2.name)
			return 1;
		else
			return 0;
	}

	bool operator<=(const fruit &F2) const
	{
		if(name <= F2.name)
			return 1;
		else
			return 0;
	}

	bool operator==(const fruit &F2) const
	{
		if(name == F2.name)
			return 1;
		else
			return 0;
	}

	void operator+=(const fruit &F2)
	{
		quantity += F2.quantity;
	}

	//data declarations
	string name;
	float quantity;
	float cost;
};

struct node {
	//constructor
	node()
	{
		F.name = "";
		next = NULL;
	}

	node(fruit temp)
	{
		F = temp;
		next = NULL;
	}

	//data declarations
	fruit F;
	node *next;
};

int main(int argc, char *argv[])
{
	//prog -inorder|sortall|sortone file.txt
	//set program mode from command line arg
	
	//error checking number of commandline arguments
	if(argc != 3)
	{
		cerr << "Incorrect amount of arguments\n";
		return 0;
	}

	string argument = argv[1];

	//error checking if argv[1] is a valid method of sorting
	if(argument != "-inorder" && argument != "-sortall" && argument != "-sortone")
	{
		cerr << "Incorrect sorting mode\n";
		return 0;
	}

	//declare linked_list<fruit>
	//creates a head node, a current node that traverses the list, and a placeholder
	//node that is used for holding a node's place in memory while inserting and deleting
	node *head = new node();
	node *current = head;
	node *placeholder;

	//open file
	string filename = argv[2];
	ifstream ifs;
	ifs.open(filename.c_str());

	string line;
	
	//-inorder insertion
	if(argument == "-inorder")
	{
		//while (reading more data)
		while(getline(ifs, line))
		{
			//taking a line from the txt file and putting the information into a fruit structure
			fruit temp;
			istringstream iss(line);
			iss >> temp.name >> temp.quantity >> temp.cost;
			
			//if the head node is empty insert fruit at head, otherwise insert fruit into a new node at the end of the list
			if(head->F.name == "")
			{
				head->F = temp;
			}
			else
			{
				current->next = new node(temp);
				current = current->next;
			}
		}
	}
	//-sortall and -sortone insertion
	else
	{
		//while (reading more data)
		while(getline(ifs, line))
		{
			//taking a line from the txt file and putting the information into a fruit structure
			fruit temp;
			istringstream iss(line);
			iss >> temp.name >> temp.quantity >> temp.cost;

			//if the head node is empty insert the fruit into it
			if(head->F.name == "")
			{
				head->F = temp;
			}
			//else if the fruit's name should come before the head, insert a new node before head and make it the head node
			else if(temp < head->F)
			{
				placeholder = head;
				head = new node(temp);
				head->next = placeholder;
			}
			//else insert the fruit somewhere in the middle or the end
			else
			{
				//bool that keeps track if the fruit has already been inserted to see if should be inserted at the end
				bool added = false;

				//traverse until current is the last node in the list
				while(current->next != NULL)
				{
					//if the name's value is less than the next node's, insert the fruit into a new node between the current node and the next node
					if(temp < current->next->F)
					{
						placeholder = current->next;
						current->next = new node(temp);
						current->next->next = placeholder;

						//set added to true, reset current to head, and break
						added = true;
						current = head;
						break;
					}
					//go to the next node in the list
					current = current->next;
				}
				//if the fruit has not been inserted yet, put it in the end
				if(added == false)
				{
					current->next = new node(temp);
				}
			}
			//reset current to head
			current = head;
		}
	}
	//close the txt file
	ifs.close();

	//reset current to head
	current = head;
	
	//if -sortone, remove all duplicates and add their quantities into one of the same fruits
	if(argument == "-sortone")
	{
		//traverse until the end of the list
		while(current->next != NULL)
		{
			//if the current node's fruit is the same fruit as the next node's
			if(current->F == current->next->F)
			{
				//add their quantities together
				current->F += current->next->F;

				//remove the next node from both the list and memory
				placeholder = current->next;
				current->next = placeholder->next;
				placeholder->next = NULL;
				delete placeholder;
			}
			else
			{
				//if the next is not the duplicate, move to the next node
				current = current->next;
			}
		}
	}

	//reset current to head and create a float that holds the total cost
	current = head;
	float total = 0.0;
	//pretty-print linked list content to stdout
	while(current != NULL)
	{
		//prints in correct format
		cout << setfill('.') << setw(20) << left << current->F.name;
		cout << ' ' << fixed << right << setprecision(2) << setfill(' ') << setw(5) << current->F.quantity;
		cout << " x " << setw(4) << current->F.cost << " = ";

		//creates Tcost which holds the current fruit's total cost and adds that to the total
		float Tcost = current->F.quantity * current->F.cost;
		total += Tcost;

		//prints out both values in the correct format
		cout << setw(7) << Tcost << "  : " << setw(8) << total << '\n';

		//move to the next node
		current = current->next;
	}
	
	//free linked list memory
	while(head != NULL)
	{
		//deletes starting from the head, and goes down the list until it is no longer within memory
		placeholder = head;
		head = head->next;
		delete placeholder;
	}

	//deletes head and current just in case
	delete head;
	delete current;
}

// Noah Morris
// CS302
// 2/2/2020
// fruit1

// list all headers needed
#include <string>
#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <algorithm>
using namespace std;

struct fruit {
	//overload operator <
	bool operator<(const fruit &F2) const
	{
		if(name < F2.name)
			return 1;
		else
			return 0;
	}

	//data
	string name;
	float quantity;
	float cost;
};

int main(int argc, char *argv[])
{
	//prog -inorder|sortall|sortone file.txt
	//set program mode from command line arg
	
	//error checking number of commandline arguments
	if(argc != 3)
	{
		cerr << "Incorrect amount of arguments\n";
		return 0;
	}

	string argument = argv[1];

	//error checking if argv[1] is a valid method of sorting
	if(argument != "-inorder" && argument != "-sortall" && argument != "-sortone")
	{
		cerr << "Incorrect sorting mode\n";
		return 0;
	}

	//declare array_list<fruit>
	vector<fruit> fruits;

	//open file
	string filename = argv[2];
	ifstream ifs;
	ifs.open(filename.c_str());

	string line;
	//while (reading more data)
	//store data INORDER
	while(getline(ifs, line))
	{
		//taking a line from the txt file and putting the information into a fruit structure
		fruit temp;
		istringstream iss(line);
		iss >> temp.name >> temp.quantity >> temp.cost;

		//insert that fruit into the vector
		fruits.push_back(temp);
	}
	//close the txt file
	ifs.close();

	//if (mode == SORTALL || mode == SORTONE)
	//apply std::stable_sort
	if(argument == "-sortall" || argument == "-sortone")
	{
		stable_sort(fruits.begin(), fruits.end());
	}

	//if (mode == SORTONE)
	//combine fruit quanties with same name
	if(argument == "-sortone")
	{
		//goes down the entire vector
		for(unsigned int i = 0; i < fruits.size(); i++)
		{
			//if i is at the final index of the vector, break out of the loop
			if(i == fruits.size() - 1)
			{
				break;
			}

			//goes down the entire vector starting from i
			for(unsigned int j = i + 1; j < fruits.size(); j++)
			{
				//if the fruit names at i and j are the same
				if(fruits.at(i).name == fruits.at(j).name)
				{
					//add the quantities together, delete index j, and j-- so
					//that j may check every index and not skip one due to deletion
					fruits.at(i).quantity += fruits.at(j).quantity;
					fruits.erase(fruits.begin() + j);
					j--;
				}
			}
		}
	}

	//pretty-print array list content to stdout
	//create a float that holds the total cost
	float total = 0.0;
	for(unsigned int i = 0; i < fruits.size(); i++)
	{
		//prints each fruit in the correct format
		cout << setfill('.') << setw(20) << left << fruits.at(i).name;
		cout << ' ' << fixed << right << setprecision(2) << setfill(' ') << setw(5) << fruits.at(i).quantity;
		cout << " x " << setw(4) << fruits.at(i).cost << " = ";

		//creates Tcost which holds the current fruit's total cost and adds it to the total
		float Tcost = fruits.at(i).quantity * fruits.at(i).cost;
		total += Tcost;

		//prints out both values in the correct format
		cout << setw(7) << Tcost << "  : " << setw(8) << total << '\n';	
	}

	//free array list memory as necessary
	//emptys fruits and clears the memory it used up
	vector<fruit>().swap(fruits);
}

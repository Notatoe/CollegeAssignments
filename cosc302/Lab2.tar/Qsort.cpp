// Noah Morris
// cs302
// 2/12/2021
// Lab2

// include header files needed
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <algorithm>
#include <iterator>
using namespace std;

class data {
	public:
		// add operator< using lastname, firstname, phone number

		friend istream & operator>>(istream &, data &);
		friend ostream & operator<<(ostream &, const data &);

		bool operator<(const data &rhs) const;

	private:
		string firstname;
		string lastname;
		string phonenum;
};

bool data::operator<(const data &rhs) const
{
	//checks lastname first
	if(lastname < rhs.lastname)
	{
		return true;
	}

	//if lastnames are equivalent, moves on to compare firstnames
	if(lastname == rhs.lastname)
	{
		if(firstname < rhs.firstname)
		{
			return true;
		}

		//if firstnames are also equivalent, moves on to compare phone numbers
		if(firstname == rhs.firstname)
		{
			if(phonenum < rhs.phonenum)
			{
				return true;
			}

			//if rhs' phone number is greater than this', return false
			return false;
		}

		//if rhs' firstname is greater than this', return false
		return false;
	}

	//if rhs' lastname is greater than this', return false
	return false;
}

istream & operator>>(istream &in, data &r) { 
	// writes to a data object in order from lastname to firstname to phonenumber
	in >> r.firstname >> r.lastname >> r.phonenum;
	return in;
}

ostream & operator<<(ostream &out, const data &r) {
	// format for how a data object should be outputted
	out << setw(24) << left << r.lastname + ", " + r.firstname << r.phonenum;
	return out;
}

	template <typename T>
void quicksort(std::vector<T> &A, int left, int right)
{
	//Partitioning
	// sort: order left, middle and right elements
	if(left < right) 
	{
		// select pivot: median-of-three replaced with random
		int pindex = rand() % (right - left + 1) + left;

		T pivot = A[pindex];
		// partition A: {<=}, {pivot}, {=>}
		swap(A[pindex], A[right]);
		int i = left;
		int j = right-1;

		//moves data around pivot by swapping
		while(1)
		{
			while(A[i] < pivot && i < right) 
			{
				i++;
			}
			while(pivot < A[j] && j > left) 
			{
				j--;
			}
			if(i >= j)
			{
				break;
			}
			swap(A[i], A[j]);
		}

		//swaps right back to where pinindex is
		pindex = i;
		swap(A[pindex], A[right]);

		//recursivly calls quicksort
		quicksort(A, left, pindex-1);
		quicksort(A, pindex+1, right);
	}
}

	template <typename T>
void quickselect(std::vector<T> &A, int left, int k, int right) 
{

	while(left < right)
	{
		// select pivot: median-of-three replaced with random
		int pindex = rand() % (right - left + 1) + left;

		T pivot = A[pindex];

		// partition A: {<=}, {pivot}, {=>}
		swap(A[pindex], A[right]);
		int i = left;
		int j = right-1;

		// moves data around the pivet by swapping
		while(1)
		{
			while(A[i] < pivot && i < right) 
			{
				i++;
			}
			while(pivot < A[j] && j > left) 
			{
				j--;
			}
			if(i >= j)
			{
				break;
			}
			swap(A[i], A[j]);
		}
		
		//swaps right back to where pindex is
		pindex = i;
		swap(A[pindex], A[right]);

		//checks for value k to see if it's in its proper place
		if(pindex == k)
		{
			return;
		}
		if(k<pindex)
		{
			right = pindex-1;
		}
		else
		{
			left = pindex+1;
		}
	}
}

void printlist(vector<data>::iterator begin, vector<data>:: iterator end) 
{
	//prints the entirity of the vector on seperate lines
	for(vector<data>::iterator i = begin; i != end; ++i)
	{
		cout << *i << '\n';
	}
}

int main(int argc, char *argv[])
{
	// perform command-line error checking
	// error message "usage: ./Qsort -stl | -rpivot [k0 k1] file.txt"
	
	string file, sortmode;

	//checks for a correct number of aguments given
	if(argc != 3 && argc != 5)
	{
		cerr << "usage: ./Qsort -stl | -rpivot [k0 k1] file.txt\n";
		return 1;
	}

	//sets sortmode to argv[1] since argv[1] is known to be there since there are 3 or 5 arguments
	sortmode = argv[1];

	//if there is 3 arguments and a correct sortmode, file is set to argv[2]
	if(sortmode == "-stl" || (sortmode == "-rpivot" && argc == 3))
	{
		file = argv[2];
	}
	//if there is 5 arguments and the sortmode is -rpivot, file is set to argv[4]
	else if(sortmode == "-rpivot" && argc == 5)
	{
		file = argv[4];
	}
	//else read out an error message and end the program
	else
	{
		cerr << "usage: ./Qsort -stl | -rpivot [k0 k1] file.txt\n";
		return 1;
	}

	//open file.txt
	ifstream ifs;
	ifs.open(file.c_str());

	//creates a vector of data
	vector<data> A;

	//takes information from the file, puts them into data objects and
	//pushes the data into the data vector
	data din;
	string line;
	while(getline(ifs, line))
	{
		istringstream iss(line);
		iss >> din;
		A.push_back(din);
	}

	//closes the file
	ifs.close();

	//if sortmode is -stl, sort the data in order
	if(sortmode ==  "-stl")
	{
		sort(A.begin(), A.end());
	}
	//else, if sortmore is -rpivot
	else if(sortmode == "-rpivot")
	{
		//set N to the size of the vector and k0 to 0 and k1 to one less than N
		int N = (int)A.size();
		int k0 = 0;
		int k1 = N-1;

		// if specified, update k0, k1 and apply quickselect 
		// to ensure that A[0:k0-1] <= A[k0:k1] <= A[k1+1:N-1]

		//if argc is 5, then k0 and k1 have predefined values inserted
		if(argc == 5)
		{
			k0 = atoi(argv[2]);
			k1 = atoi(argv[3]);

			//if the k0 or k1 values are out of the range of the vector,
			//set them to the default endpoint values
			if(k0 < 0)
			{
				k0 = 0;
			}
			if(k1 > N)
			{
				k1 = N-1;
			}

			//sort by placing k0 and k1 in their correct positions
			quickselect(A, 0, k0, N-1);
			quickselect(A, k0, k1, N-1);
		}

		//sorts using quicksort between indexes k0 and N-1
		quicksort(A, k0, N-1);
	} 

	//prints out the data within the vector
	printlist(A.begin(), A.end());
}

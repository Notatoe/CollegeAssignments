#ifndef __PPM_H__
#define __PPM_H__
#include <string>
using namespace std;

//RGB structure that holds an R, B, and G char
struct RGB {
	RGB() {
		R=0;
		G=0;
		B=0;
	}

	unsigned char R, G, B;
};

class PPM {
	public:
		//constructor that initializes everything to 0
		PPM() {
			rows = 0;
			columns = 0;
			maxvalue = 0;
			ID = "";
		}

		//destructor that delete everything in the 2d img array
		~PPM() {
			for(int i=0; i < get_Nrows(); ++i) 
			{
				delete [] img[i];
			}
			delete [] img;
		}

		//initializations for a read and write function
		void read(string);
		void write(string);

		//operator for accessing rows of img
		RGB *operator[](int num) 
		{
			return img[num];
		}

		//accessor functions
		int get_Nrows() {return rows;}
		int get_Ncols() {return columns;}

	private:
		//data members
		int rows;
		int columns;
		int maxvalue;
		string ID;

		RGB **img;
};

#endif

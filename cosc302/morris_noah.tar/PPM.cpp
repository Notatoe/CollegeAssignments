#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
using namespace std;

#include "PPM.h"

void PPM::read(string filename) 
{
	//istream that reads in from the inputted file
	ifstream ifs(filename.c_str());

	//gets the given values that are on all PPM images
	ifs >> ID >> columns >> rows >> maxvalue;

	//initializes thedouble array of RGB in the PPM
	img = new RGB *[rows];
	for (int i = 0; i < rows; i++) 
	{
		img[i]= new RGB [columns];
	}

	//creates a buffer with the appropriate amount of memory resereved
	int memsize = rows * columns * 3;
	char *buffer= new char [memsize];

	//skips any newlines that may effect the buffer
	while(ifs.get() != '\n')
	{
		continue;
	}

	//reads the file into buffer 
	ifs.read(buffer, memsize);

	//temp holds onto the current index, for loop inserts every value into their
	//respective RGB values in the PPM
	int temp = 0;
	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < columns; j++) {
			img[i][j].R= buffer[temp];
			temp++;
			img[i][j].G= buffer[temp];
			temp++;
			img[i][j].B= buffer[temp];
			temp++;
		}
	}

	//closes the filestream
	ifs.close();
}


void PPM::write(string filename) 
{
	//replaces the end of the file name with _wmsg.ppm instead of .ppm
	filename.erase(filename.size()-4, 4);
	filename += "_wmsg.ppm";

	//opens a new file using the new file name
	ofstream os;
	os.open(filename.c_str());

	//sets the intitial values where they should be in PPM images
	os << ID << '\n' << columns << ' ' << rows << '\n' << maxvalue << '\n';


	//inserts the RGB values of every index in order of when should appear
	for (int i = 0; i < get_Nrows(); i++) {
		for (int j = 0; j < get_Ncols(); j++) {
			os << img[i][j].R << img[i][j].G << img [i][j].B;
		}
	}

	//adds a newline once finished and closes the new file
	os << endl;
	os.close();
}
